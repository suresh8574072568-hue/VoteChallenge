VOTE CHALLENGE - ANDROID PROJECT

This is an Android Studio project, not a precompiled APK.

Build your APK:
1. Install Android Studio on a computer.
2. Extract VoteChallenge-AndroidStudio-Project.zip.
3. In Android Studio choose File > Open and select the VoteChallenge folder.
4. Wait for Gradle sync to finish.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When finished, click Locate. Android Studio will show app-debug.apk.

App behavior:
- Tap the red Modi Jee panel to add one to its score.
- Tap the blue Rahul Jee panel to add one to its score.
- Reset Score returns both scores to zero.
- Scores are preserved through normal screen recreation.
- Personal fun counter; not an official poll.
