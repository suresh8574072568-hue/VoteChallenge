package com.vkd.votechallenge

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private var leftScore = 0
    private var rightScore = 0
    private lateinit var leftCount: TextView
    private lateinit var rightCount: TextView
    private lateinit var total: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        leftScore = savedInstanceState?.getInt("left", 0) ?: 0
        rightScore = savedInstanceState?.getInt("right", 0) ?: 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(24), dp(18), dp(24))
            setBackgroundColor(Color.rgb(15, 18, 28))
        }
        val heading = TextView(this).apply {
            text = "⚡ FUNNY VOTE CHALLENGE ⚡"
            textSize = 23f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        }
        val subheading = TextView(this).apply {
            text = "Tap a side to add one vote"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        }
        root.addView(heading, matchWrap())
        root.addView(subheading, matchWrap())

        val scoreboard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(Color.WHITE, 24)
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        val leftPanel = makePanel("Modi Jee", "🕶️", Color.rgb(231, 62, 55))
        val rightPanel = makePanel("Rahul Jee", "😎", Color.rgb(27, 105, 230))
        leftCount = leftPanel.second
        rightCount = rightPanel.second
        scoreboard.addView(leftPanel.first, LinearLayout.LayoutParams(0, dp(265), 1f))
        scoreboard.addView(rightPanel.first, LinearLayout.LayoutParams(0, dp(265), 1f))
        root.addView(scoreboard, LinearLayout.LayoutParams(-1, -2))

        total = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, dp(18))
        }
        root.addView(total, matchWrap())
        val reset = Button(this).apply {
            text = "RESET SCORE"
            textSize = 15f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(52, 58, 72), 16)
            setPadding(dp(28), dp(12), dp(28), dp(12))
            setOnClickListener { leftScore = 0; rightScore = 0; refresh() }
        }
        root.addView(reset, LinearLayout.LayoutParams(-2, -2))
        val note = TextView(this).apply {
            text = "Personal fun counter • Not an official poll"
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, 0)
        }
        root.addView(note, matchWrap())
        setContentView(root)
        refresh()
    }

    private fun makePanel(name: String, emoji: String, color: Int): Pair<LinearLayout, TextView> {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackground(rounded(color, 20))
            isClickable = true
            isFocusable = true
            setPadding(dp(6), dp(16), dp(6), dp(16))
        }
        val icon = TextView(this).apply { text = emoji; textSize = 30f; gravity = Gravity.CENTER }
        val label = TextView(this).apply {
            text = name; textSize = 19f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(14))
        }
        val count = TextView(this).apply {
            text = "0"; textSize = 54f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD); gravity = Gravity.CENTER
            setShadowLayer(3f, 1f, 2f, 0x66000000)
        }
        panel.addView(icon, matchWrap())
        panel.addView(label, matchWrap())
        panel.addView(count, matchWrap())
        panel.setOnClickListener {
            if (name == "Modi Jee") leftScore++ else rightScore++
            refresh()
        }
        return Pair(panel, count)
    }

    private fun refresh() {
        if (!::leftCount.isInitialized) return
        leftCount.text = leftScore.toString()
        rightCount.text = rightScore.toString()
        total.text = "TOTAL VOTES: ${leftScore + rightScore}"
    }
    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt("left", leftScore); outState.putInt("right", rightScore)
        super.onSaveInstanceState(outState)
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
